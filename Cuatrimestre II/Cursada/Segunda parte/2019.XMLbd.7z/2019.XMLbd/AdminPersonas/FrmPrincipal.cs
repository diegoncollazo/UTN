﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;
using System.IO;
using System.Data.SqlClient;

using Entidades;

namespace AdminPersonas
{
    public partial class FrmPrincipal : Form
    {
        SqlConnection conex = new SqlConnection(Properties.Settings.Default.conexion);
        SqlCommand _comando = new SqlCommand();
        SqlDataReader sqlDataReader;

        private List<Persona> lista;

        public FrmPrincipal()
        {
            InitializeComponent();

            this.IsMdiContainer = true;
            this.WindowState = FormWindowState.Maximized;

            this.lista = new List<Persona>();
        }

        private void cargarArchivoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //implementar...
            Persona persona = new Persona();
            try
            {
                XmlSerializer xml = new XmlSerializer(typeof(Persona));
                StreamReader sw = new StreamReader("D:\\alumno.xml");
                persona = (Persona)xml.Deserialize(sw);
                sw.Close();
            }
            catch
            {
                Console.WriteLine("No se puedo abrir el archivo.");
            }
        }

        private void guardarEnArchivoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //implementar...
        }

        private void visualizarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmVisorPersona frm = new frmVisorPersona();

            frm.StartPosition = FormStartPosition.CenterScreen;

           

            frm.Show();
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //implementar
        }

        private void conexionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            try
            {
                this._comando = new SqlCommand();
                this._comando.Connection = this.conex;
                this._comando.CommandType = CommandType.Text;
                this._comando.CommandText = "SELECT [nombre],[apellido],[edad]FROM[personas_bd].[dbo].[personas]";

                this.conex.Open();

                sqlDataReader = this._comando.ExecuteReader();

                while (sqlDataReader.Read())
                {
                    Persona persona = new Persona(sqlDataReader["nombre"].ToString(), sqlDataReader["apellido"].ToString(), (int)sqlDataReader["edad"]);
                    lista.Add(persona);
                    MessageBox.Show(sqlDataReader[0].ToString() + sqlDataReader[1].ToString());
                }
                //indice o nombre de columna
                
            }
            catch
            {

            }
        }
    }
}

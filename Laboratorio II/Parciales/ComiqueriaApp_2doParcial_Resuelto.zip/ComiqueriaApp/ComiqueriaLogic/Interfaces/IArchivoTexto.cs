﻿namespace ComiqueriaLogic
{
    public interface IArchivoTexto
    {
        string Texto { get; }
        string Ruta { get; }
    }
}
